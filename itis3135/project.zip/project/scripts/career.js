$(document).ready(function() {
    $("#accordion").accordion({
        collapsible: true,
        heightStyle: "content"
    });
});