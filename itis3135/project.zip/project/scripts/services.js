let show_hide = function()
{
    if ($("#details_1").is(":visible"))
    {
        $("#details_1").hide();
    }
    else
    {
        $("#details_1").show();
    }
}

let show_hide2 = function()
{
    if ($("#details_2").is(":visible"))
    {
        $("#details_2").hide();
    }
    else
    {
        $("#details_2").show();
    }
}

let show_hide3 = function()
{
    if ($("#details_3").is(":visible"))
    {
        $("#details_3").hide();
    }
    else
    {
        $("#details_3").show();
    }
}

let show_hide4 = function()
{
    if ($("#details_4").is(":visible"))
    {
        $("#details_4").hide();
    }
    else
    {
        $("#details_4").show();
    }
}

let show_hide5 = function()
{
    if ($("#details_5").is(":visible"))
    {
        $("#details_5").hide();
    }
    else
    {
        $("#details_5").show();
    }
}

let show_hide6 = function()
{
    if ($("#details_6").is(":visible"))
    {
        $("#details_6").hide();
    }
    else
    {
        $("#details_6").show();
    }
}

let show_hide7 = function()
{
    if ($("#details_7").is(":visible"))
    {
        $("#details_7").hide();
    }
    else
    {
        $("#details_7").show();
    }
}